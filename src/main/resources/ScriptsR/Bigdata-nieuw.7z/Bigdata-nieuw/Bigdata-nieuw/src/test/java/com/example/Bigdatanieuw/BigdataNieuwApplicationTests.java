package com.example.Bigdatanieuw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BigdataNieuwApplicationTests {

	@Test
	void contextLoads() {
	}

}
