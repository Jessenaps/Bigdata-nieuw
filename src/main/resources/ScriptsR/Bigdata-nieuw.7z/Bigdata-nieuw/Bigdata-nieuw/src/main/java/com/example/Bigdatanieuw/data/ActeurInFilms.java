package com.example.Bigdatanieuw.data;


public class ActeurInFilms {
    public String name;
    public long aantal_films;

    public ActeurInFilms(String name,long aantal_films) {
        this.name = name;
        this.aantal_films = aantal_films;

    }

}